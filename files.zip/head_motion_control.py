"""
Head Motion -> Virtual Desktop Switcher
-----------------------------------------
Turn your head to the EXTREME left or right (past the red threshold
lines) to send Win+Ctrl+Left / Win+Ctrl+Right, switching Windows
virtual desktops. Staying near center does nothing.

Two live sliders appear at the TOP of the video window (OpenCV can't
place sliders at the bottom, this is a library limitation):
  - "Threshold %"  : how far from center (5-45%) counts as extreme.
                     LOWER = more sensitive (red lines closer together,
                     easier to trigger). HIGHER = less sensitive.
  - "Cooldown (s)" : seconds to wait after a trigger before it can
                     fire again (1-30).

Install first:
    pip install opencv-python mediapipe==0.10.21 pyautogui numpy psutil

Run (from Command Prompt):
    python "C:\\Users\\Eklavya Gaur\\Downloads\\head_motion_control.py"

Press 'q' in the video window to quit.
"""

import time
import os
import cv2
import mediapipe as mp
import pyautogui
import psutil

pyautogui.FAILSAFE = True

mp_face_mesh = mp.solutions.face_mesh
NOSE_TIP = 1

WINDOW_NAME = "Head Motion Control"

# ---- Defaults for sliders ----
DEFAULT_THRESHOLD_PCT = 35   # -> LEFT/RIGHT lines at 0.15 / 0.85... wait see below
MIN_THRESHOLD_PCT = 5
MAX_THRESHOLD_PCT = 45
DEFAULT_COOLDOWN = 5
MIN_COOLDOWN = 1
MAX_COOLDOWN = 30

SMOOTH_FRAMES = 3   # small rolling average to reduce jitter

# Logical CPU indices to pin to (avoid hot P-cores 1-6). Run
# check_core_mapping.py once to confirm these indices on your machine.
CPU_AFFINITY = [7, 8, 9]


def pin_to_cores(indices):
    try:
        p = psutil.Process(os.getpid())
        available = p.cpu_affinity()
        valid = [i for i in indices if i in available]
        if valid:
            p.cpu_affinity(valid)
            print(f"Pinned process to logical CPUs: {valid}")
        else:
            print("Requested CPU indices not available, running unpinned.")
    except Exception as e:
        print(f"Could not set CPU affinity ({e}), running unpinned.")


def nothing(_):
    pass


def main():
    pin_to_cores(CPU_AFFINITY)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam")
        return

    cv2.namedWindow(WINDOW_NAME)
    # Trackbar range is 0-based in OpenCV, so we offset for the real min value.
    cv2.createTrackbar(
        "Threshold %", WINDOW_NAME,
        DEFAULT_THRESHOLD_PCT - MIN_THRESHOLD_PCT,
        MAX_THRESHOLD_PCT - MIN_THRESHOLD_PCT,
        nothing,
    )
    cv2.createTrackbar(
        "Cooldown (s)", WINDOW_NAME,
        DEFAULT_COOLDOWN - MIN_COOLDOWN,
        MAX_COOLDOWN - MIN_COOLDOWN,
        nothing,
    )

    with mp_face_mesh.FaceMesh(
        max_num_faces=1,
        refine_landmarks=False,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ) as face_mesh:

        last_trigger_time = 0.0
        recent_x = []

        print("Running. Press 'q' in the video window to quit.")

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Read live slider values
            threshold_pct = MIN_THRESHOLD_PCT + cv2.getTrackbarPos("Threshold %", WINDOW_NAME)
            cooldown_seconds = MIN_COOLDOWN + cv2.getTrackbarPos("Cooldown (s)", WINDOW_NAME)
            left_threshold = 0.5 - (threshold_pct / 100)
            right_threshold = 0.5 + (threshold_pct / 100)

            frame = cv2.flip(frame, 1)  # mirror so left/right feels natural
            h, w, _ = frame.shape
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb)

            status_text = "No face"
            status_color = (0, 0, 255)

            if results.multi_face_landmarks:
                landmarks = results.multi_face_landmarks[0].landmark
                nose = landmarks[NOSE_TIP]

                recent_x.append(nose.x)
                if len(recent_x) > SMOOTH_FRAMES:
                    recent_x.pop(0)
                x = sum(recent_x) / len(recent_x)

                now = time.time()
                time_since_last = now - last_trigger_time
                on_cooldown = time_since_last < cooldown_seconds

                if x < left_threshold:
                    status_text = "EXTREME LEFT"
                    status_color = (0, 165, 255)
                    if not on_cooldown:
                        pyautogui.hotkey('winleft', 'ctrl', 'left')
                        print("Extreme left -> Win+Ctrl+Left")
                        last_trigger_time = now
                elif x > right_threshold:
                    status_text = "EXTREME RIGHT"
                    status_color = (0, 165, 255)
                    if not on_cooldown:
                        pyautogui.hotkey('winleft', 'ctrl', 'right')
                        print("Extreme right -> Win+Ctrl+Right")
                        last_trigger_time = now
                else:
                    status_text = "Center (no action)"
                    status_color = (0, 255, 0)

                if on_cooldown:
                    status_text += f" [cooldown {cooldown_seconds - time_since_last:.1f}s]"

                cv2.line(frame, (int(left_threshold * w), 0), (int(left_threshold * w), h), (0, 0, 255), 1)
                cv2.line(frame, (int(right_threshold * w), 0), (int(right_threshold * w), h), (0, 0, 255), 1)

                cx, cy = int(x * w), int(nose.y * h)
                cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)

            cv2.putText(frame, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2)
            cv2.putText(frame, f"Threshold: {threshold_pct}%  Cooldown: {cooldown_seconds}s",
                        (10, h - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

            cv2.imshow(WINDOW_NAME, frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
